function genChar() {
    const genders = ["Male", "Female", "Non-binary"];
    const species = ["Human", "Elf", "Orc", "Fairy","Spirit"];
    const roles = ["Warrior", "Mage", "Healer", "Thief","Rogue"];
    const elements = ["Fire", "Water", "Earth", "Air","Nature","Darkness"];
    const ages = ["Teen", "Adult", "Elder"];

    document.getElementById('gender').value = getRandomItem(genders);
    document.getElementById('species').value = getRandomItem(species);
    document.getElementById('role').value = getRandomItem(roles);
    document.getElementById('element').value = getRandomItem(elements);
    document.getElementById('age').value = getRandomItem(ages);
}

function getRandomItem(array) {
    return array[Math.floor(Math.random() * array.length)];
}

fetch('http://localhost:5000/api/data')
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(error => console.error('Error fetching data:', error));


  async function getData() {
    const response = await fetch('http://localhost:5000/api/data');
    const data = await response.json();
    document.getElementById('response').textContent = data.message;
}

getData();